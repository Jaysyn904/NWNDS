----------------------------------------------------------------------------
-- Lua code generated with wxFormBuilder (version Jun 17 2015)
-- http://www.wxformbuilder.org/
----------------------------------------------------------------------------

-- Load the wxLua module, does nothing if running from wxLua, wxLuaFreeze, or wxLuaEdit
package.cpath = package.cpath..";./?.dll;./?.so;../lib/?.so;../lib/vc_dll/?.dll;../lib/bcc_dll/?.dll;../lib/mingw_dll/?.dll;"
require("wx")

UI = {}

-- create mainWindow
	UI.mainWindow = wx.wxFrame (wx.NULL, wx.wxID_ANY, "Nwn1 Spell Calculator", wx.wxDefaultPosition, wx.wxSize( 300,280 ), wx.wxCAPTION + wx.wxCLOSE_BOX + wx.wxMINIMIZE_BOX + wx.wxSYSTEM_MENU+wx.wxTAB_TRAVERSAL )
	UI.mainWindow:SetSizeHints( wx.wxDefaultSize, wx.wxDefaultSize )
	UI.mainWindow :SetBackgroundColour( wx.wxSystemSettings.GetColour( wx.wxSYS_COLOUR_MENU ) )
	
	UI.bSizer1 = wx.wxBoxSizer( wx.wxVERTICAL )
	
	UI.gSizer9 = wx.wxGridSizer( 0, 2, 0, 0 )
	
	UI.fgSizer1 = wx.wxFlexGridSizer( 0, 1, 0, 0 )
	UI.fgSizer1:SetFlexibleDirection( wx.wxBOTH )
	UI.fgSizer1:SetNonFlexibleGrowMode( wx.wxFLEX_GROWMODE_SPECIFIED )
	
	UI.meta = wx.wxStaticText( UI.mainWindow, wx.wxID_ANY, "MetaMagic", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.meta:Wrap( -1 )
	UI.fgSizer1:Add( UI.meta, 0, wx.wxALL, 5 )
	
	UI.empsp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "empower spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.empsp, 0, wx.wxALL, 5 )
	
	UI.extsp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "extend spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.extsp, 0, wx.wxALL, 5 )
	
	UI.maxsp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "maximize spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.maxsp, 0, wx.wxALL, 5 )
	
	UI.quicksp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "quicken spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.quicksp, 0, wx.wxALL, 5 )
	
	UI.silsp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "silent spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.silsp, 0, wx.wxALL, 5 )
	
	UI.stsp = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "still spell", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer1:Add( UI.stsp, 0, wx.wxALL, 5 )
	
	
	UI.fgSizer1:Add( 0, 23, 1, wx.wxEXPAND, 5 )
	
	UI.MetaMagicRes = wx.wxTextCtrl( UI.mainWindow, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_RIGHT )
	UI.fgSizer1:Add( UI.MetaMagicRes, 0, wx.wxALL, 5 )
	
	
	UI.gSizer9:Add( UI.fgSizer1, 1, wx.wxEXPAND, 5 )
	
	UI.fgSizer3 = wx.wxFlexGridSizer( 0, 1, 0, 0 )
	UI.fgSizer3:SetFlexibleDirection( wx.wxBOTH )
	UI.fgSizer3:SetNonFlexibleGrowMode( wx.wxFLEX_GROWMODE_SPECIFIED )
	
	UI.type = wx.wxStaticText( UI.mainWindow, wx.wxID_ANY, "TargetType", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.type:Wrap( -1 )
	UI.fgSizer3:Add( UI.type, 0, wx.wxALL, 5 )
	
	UI.self = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "self", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.self, 0, wx.wxALL, 5 )
	
	UI.crea = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "creature", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.crea, 0, wx.wxALL, 5 )
	
	UI.agr = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "area/ground", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.agr, 0, wx.wxALL, 5 )
	
	UI.item = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "items", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.item, 0, wx.wxALL, 5 )
	
	UI.door = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "doors", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.door, 0, wx.wxALL, 5 )
	
	UI.plc = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "placeables", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.plc, 0, wx.wxALL, 5 )
	
	UI.trig = wx.wxCheckBox( UI.mainWindow, wx.wxID_ANY, "triggers", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.trig, 0, wx.wxALL, 5 )
	
	UI.TargetTypeRes = wx.wxTextCtrl( UI.mainWindow, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_RIGHT )
	UI.fgSizer3:Add( UI.TargetTypeRes, 0, wx.wxALL, 5 )
	
	UI.generate = wx.wxButton( UI.mainWindow, wx.wxID_ANY, "Calculate", wx.wxDefaultPosition, wx.wxDefaultSize, 0 )
	UI.fgSizer3:Add( UI.generate, 0, wx.wxALL, 5 )
	
	
	UI.gSizer9:Add( UI.fgSizer3, 1, wx.wxEXPAND, 5 )
	
	
	UI.bSizer1:Add( UI.gSizer9, 1, wx.wxEXPAND, 5 )
	
	
	UI.mainWindow:SetSizer( UI.bSizer1 )
	UI.mainWindow:Layout()
	
	UI.mainWindow:Centre( wx.wxBOTH )
	
	-- Connect Events
	
	UI.generate:Connect( wx.wxEVT_COMMAND_BUTTON_CLICKED, function(event)
	--implements calculate
	
		local mmagcalc = 0
		local oempower = 0
		local oextend = 0
		local omaximize = 0
		local oquicken = 0
		local osilent = 0
		local ostill = 0

		local uiempsel = UI.empsp:GetValue()
		local uiexsel = UI.extsp:GetValue()
		local uimaxsel = UI.maxsp:GetValue()
		local uiqusel = UI.quicksp:GetValue()
		local uisilsel = UI.silsp:GetValue()
		local uistsel = UI.stsp:GetValue()
		
		if uiempsel == true then
			oempower = 1
		end
		
		if uiexsel == true then
			oextend = 1
		end
		
		if uimaxsel == true then
			omaximize = 1
		end
		
		if uiqusel == true then
			oquicken = 1
		end
		
		if uisilsel == true then
			osilent = 1
		end
		
		if uistsel == true then
			ostill = 1
		end
		
		mmagcalc = ( oempower * 1 ) + ( oextend * 2 ) + ( omaximize * 4 ) + ( oquicken * 8 ) + ( osilent * 16 ) + ( ostill * 32 )
		local output1 = string.format("%x", mmagcalc)
		if mmagcalc <= 15 then
			UI.MetaMagicRes:SetValue ( '0x0' .. output1 )
		elseif mmagcalc > 15 then
			UI.MetaMagicRes:SetValue ( '0x' .. output1 )
		end
		
		local ttypecalc = 0
		local oself = 0
		local ocreature = 0
		local oarea = 0
		local oitem = 0
		local odoor = 0
		local oplc = 0
		local otrigger = 0
		
		local uiself = UI.self:GetValue()
		local uicrea = UI.crea:GetValue()
		local uiarea = UI.agr:GetValue()
		local uiitem = UI.item:GetValue()
		local uidoor = UI.door:GetValue()
		local uiplc = UI.plc:GetValue()
		local uitrig = UI.trig:GetValue()
		
		if uiself == true then
			oself = 1
		end
		
		if uicrea == true then
			ocreature = 1
		end
		
		if uiarea == true then
			oarea = 1
		end
		
		if uiitem == true then
			oitem = 1
		end
		
		if uidoor == true then
			odoor = 1
		end
		
		if uiplc == true then
			oplc = 1
		end
		
		if uitrig == true then
			otrigger = 1
		end
		
		ttypecalc = ( oself * 1 ) + ( ocreature * 2 ) + ( oarea * 4 ) + ( oitem * 8 ) + ( odoor * 16 ) + ( oplc * 32 ) + ( otrigger * 64 )
		local output2 = string.format("%x", ttypecalc)
		if ttypecalc <= 15 then		
			UI.TargetTypeRes:SetValue ( '0x0' .. output2 )
		elseif ttypecalc > 15 then
			UI.TargetTypeRes:SetValue ( '0x' .. output2 )
		end
	event:Skip()
	end )


UI.mainWindow:Show()
wx.wxGetApp():MainLoop()